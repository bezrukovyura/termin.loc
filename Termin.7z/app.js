/// <reference path="./node_modules/@types/angularjs/angular.d.ts" />
/// <reference path="./node_modules/@types/jquery/index.d.ts" />
var aspdApp = angular.module('termin', [])
    .component("formInputComponent", Termin.formInputComponent);
//# sourceMappingURL=app.js.map