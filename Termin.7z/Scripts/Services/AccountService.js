var Termin;
(function (Termin) {
    var Services;
    (function (Services) {
        var AccountService = /** @class */ (function () {
            function AccountService($http, $q) {
                this.$http = $http;
                this.$q = $q;
            }
            AccountService.prototype.HasAccess = function () {
                var _this = this;
                return this.login("Иван", "123").then(function (response) {
                    if (response)
                        console.log("logIn ok");
                    else
                        console.log("logIn bad");
                }, function (r) {
                    return _this.$q.reject(r.data);
                });
            };
            AccountService.prototype.login = function (login, password) {
                var _this = this;
                var accountData = { login: login, password: password };
                return this.$http.post(AccountService.baseUrl + "userPermissions", accountData)
                    .then(function (response) {
                    return response.data;
                }, function (r) {
                    return _this.$q.reject(r.data);
                });
            };
            ;
            AccountService.prototype.savePass = function (accountData) {
                localStorage.setItem(AccountService.storagePath, JSON.stringify({ login: accountData.login, password: accountData.password }));
            };
            ;
            AccountService.prototype.loginOut = function () {
                localStorage.setItem(AccountService.storagePath, "");
            };
            ;
            AccountService.prototype.getAccess = function () {
                try {
                    var json = JSON.parse(localStorage.getItem(AccountService.storagePath));
                    if (json.login.length > 0 && json.password.length > 0) {
                        this.login(json.login, json.password).then(function (x) {
                            debugger;
                        }).catch(function (x) {
                            debugger;
                        });
                    }
                }
                catch (_a) {
                }
            };
            AccountService.$inject = ["$http", "$q"];
            AccountService.baseUrl = "/Account/";
            AccountService.storagePath = "login";
            return AccountService;
        }());
        Services.AccountService = AccountService;
    })(Services = Termin.Services || (Termin.Services = {}));
})(Termin || (Termin = {}));
//# sourceMappingURL=AccountService.js.map