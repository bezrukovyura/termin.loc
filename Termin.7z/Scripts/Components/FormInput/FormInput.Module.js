var Termin;
(function (Termin) {
    var Components;
    (function (Components) {
        var FormInputController = /** @class */ (function () {
            function FormInputController($scope) {
                this.$scope = $scope;
                this.data = "1234";
            }
            FormInputController.prototype.$onInit = function () {
            };
            FormInputController.$inject = [
                "$scope",
            ];
            return FormInputController;
        }());
        Components.FormInputComponent = {
            bindings: {
                guid: "@"
            },
            controller: FormInputController,
            controllerAs: "ctrl",
            template: "{{ctrl.data}}",
        };
    })(Components = Termin.Components || (Termin.Components = {}));
})(Termin || (Termin = {}));
//# sourceMappingURL=FormInput.Module.js.map