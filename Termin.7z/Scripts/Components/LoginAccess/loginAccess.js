var Termin;
(function (Termin) {
    var Components;
    (function (Components) {
        var LoginAccessController = /** @class */ (function () {
            function LoginAccessController($scope, account) {
                this.$scope = $scope;
                this.account = account;
                this.data = "qwer";
            }
            LoginAccessController.prototype.$onInit = function () {
            };
            LoginAccessController.$inject = [
                "$scope",
                "$injector",
                "AccountService"
            ];
            return LoginAccessController;
        }());
        Components.LoginAccessComponent = {
            bindings: {
                guid: "@"
            },
            controller: LoginAccessController,
            controllerAs: "ctrl",
            template: "{{ctrl.data}}",
        };
    })(Components = Termin.Components || (Termin.Components = {}));
})(Termin || (Termin = {}));
//# sourceMappingURL=loginAccess.js.map